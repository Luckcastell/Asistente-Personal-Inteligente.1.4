from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
# Importamos Document para crear los trozos de memoria conversacional
from langchain_core.documents import Document 
from groq import Groq
import os, shutil
from dotenv import load_dotenv

# Cargar variables de entorno (como la API Key de Groq)
load_dotenv()

# --- Configuración y Inicialización ---

# Inicializar cliente de Groq (para el modelo de lenguaje)
CLAVE_GROQ = os.getenv("GROQ_API_KEY")
if not CLAVE_GROQ:
    # Levantar una excepción si la clave no está configurada, crucial para la ejecución
    raise ValueError("GROQ_API_KEY no encontrada. Por favor, revisá el archivo .env")

cliente_llm = Groq(api_key=CLAVE_GROQ)

# Directorios para archivos y base de datos de vectores
DIRECTORIO_SUBIDAS = "uploads"
DIRECTORIO_DB = "vector_db"

# Constante para identificar y prefijar los trozos de memoria del chat
PREFIJO_CHAT = "MEMORIA_CHAT: "

# Crear directorios si no existen
os.makedirs(DIRECTORIO_SUBIDAS, exist_ok=True)
os.makedirs(DIRECTORIO_DB, exist_ok=True)

# Inicializar FastAP
app = FastAPI(title="Backend Suriel RAG")

# Configurar CORS (necesario para que el frontend pueda comunicarse)
app.add_middleware(
    CORSMiddleware,
    # Permitir cualquier origen durante el desarrollo. En producción, se debería restringir
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializar Embeddings (función para convertir texto a vectores)
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# Inicializar ChromaDB (la base de datos de vectores) y cargar la base persistente
# Esta base contendrá tanto los trozos de PDF como la memoria del chat
vectorstore = Chroma(
    persist_directory=DIRECTORIO_DB,
    embedding_function=embeddings
)

# Clase de Pydantic para validar la solicitud de chat
class SolicitudChat(BaseModel):
    """Define la estructura de datos esperada para la solicitud de chat."""
    mensaje: str

# --- Funciones de Lógica RAG ---

def agregar_pdf_a_vectorstore(ruta_archivo: str):
    """
    Procesa un archivo PDF, lo divide en trozos y los indexa en la base de vectores.
    :param ruta_archivo: La ruta completa al archivo PDF a procesar.
    """
    try:
        # Cargar el documento PDF
        cargador = PyPDFLoader(ruta_archivo)
        documentos = cargador.load()

        # Dividir el texto en trozos para la búsqueda precisa
        divisor_texto = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        trozos = divisor_texto.split_documents(documentos)

        # Agregar los trozos a la tienda de vectores
        vectorstore.add_documents(trozos)

        # Persistir los cambios en el disco para que estén disponibles después de reiniciar
        vectorstore.persist()
        return True
    except Exception as e:
        print(f"Error al procesar PDF {ruta_archivo}: {e}")
        return False

# --- Rutas de la API ---

@app.post("/upload")
async def subir_pdf(file: UploadFile = File(...)):
    """
    Ruta para subir un archivo PDF, guardarlo temporalmente y luego indexarlo.
    """
    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Solo se permiten archivos PDF.")

    ruta_archivo = os.path.join(DIRECTORIO_SUBIDAS, file.filename)

    try:
        # Guardar el archivo temporalmente
        with open(ruta_archivo, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # Procesar el archivo y agregarlo a la base de vectores
        if agregar_pdf_a_vectorstore(ruta_archivo):
            # Eliminar el archivo temporal después de procesar
            os.remove(ruta_archivo)
            return {"mensaje": f"PDF '{file.filename}' cargado y agregado al índice."}
        else:
            raise HTTPException(status_code=500, detail="Error interno al procesar el PDF.")

    except Exception as e:
        # En caso de error, aseguramos la limpieza del archivo temporal
        if os.path.exists(ruta_archivo):
            os.remove(ruta_archivo)
        print(f"Error en la ruta /upload: {e}")
        raise HTTPException(status_code=500, detail=f"Ocurrió un error: {e}")

@app.post("/chat")
async def chat(solicitud: SolicitudChat):
    """
    Ruta para enviar un mensaje de chat, buscar contexto (documentos y memoria de chat)
    y luego generar una respuesta.
    """
    try:
        # Paso 1: Recuperación (Retrieval) - Buscar documentos MÁS historial de chat relevante
        # Usamos k=5 para obtener más contexto, esperando capturar tanto documentos como turns de chat
        resultados = vectorstore.similarity_search(solicitud.mensaje, k=5)
        
        # Separar el contexto de documentos (PDFs) del contexto de conversación (memoria)
        contexto_documentos = []
        contexto_conversacion = []
        
        for doc in resultados:
            # Si el contenido empieza con el prefijo, es un turno de chat anterior (memoria)
            if doc.page_content.startswith(PREFIJO_CHAT):
                # Limpiamos el prefijo para la inyección en el prompt
                contexto_conversacion.append(doc.page_content.replace(PREFIJO_CHAT, ""))
            else:
                contexto_documentos.append(doc.page_content)

        # Formatear el contexto para el prompt
        contexto_doc_str = "\n\n".join(contexto_documentos)
        contexto_chat_str = "\n".join(contexto_conversacion)
        
        # Paso 2: Aumento (Augmentation) - Crear el prompt mejorado con la memoria
        prompt = f"""Eres Suriel, un asistente amable y servicial que responde SOLO con la información de la base de datos privada.
Si la respuesta no está claramente en la base de datos, responde simplemente: "No tengo esa información en mi base de conocimiento actual."
No inventes ni uses conocimiento externo. Responde en español argentino.

---
HISTORIAL DE CONVERSACIÓN RELEVANTE (Memoria del Chat):
{contexto_chat_str if contexto_chat_str else "No hay historial relevante."}
---

Contexto de Documentos (PDFs subidos):
{contexto_doc_str}
---

Pregunta del usuario: {solicitud.mensaje}
Respuesta:
"""

        # Paso 3: Generación (Generation) - Llamar al modelo de lenguaje
        respuesta_llm = cliente_llm.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "Eres Suriel, un asistente amable y servicial."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2, # Temperatura baja para respuestas más fácticas
        )

        respuesta_generada = respuesta_llm.choices[0].message.content

        # Paso 4: Persistencia (Persistence) - Guardar el turno actual como memoria para futuras consultas
        # Almacenamos la pregunta del usuario y la respuesta de Suriel en un solo trozo
        turno_completo = f"USUARIO: {solicitud.mensaje}\nSURIEL: {respuesta_generada}"
        
        # Creamos un documento con el prefijo especial
        documento_memoria = Document(
            page_content=PREFIJO_CHAT + turno_completo, 
            metadata={
                "tipo": "chat_turn", 
                "source": "Memoria del Chat"
            }
        )

        # Agregamos el documento a la base y persistimos para que esté disponible inmediatamente
        vectorstore.add_documents([documento_memoria])
        vectorstore.persist()

        # Devolvemos la respuesta generada por el LLM
        return {"respuesta": respuesta_generada}

    except Exception as e:
        # Capturamos la excepción para el debugging
        print(f"Error en la ruta /chat: {e}")
        # Retornamos un error HTTP amigable para el frontend
        raise HTTPException(status_code=500, detail=f"Error interno al generar la respuesta: {e}")

# Punto de inicio para Uvicorn si se ejecuta directamente
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
